const path = require('path');
const express = require('express');
const http = require('http');
const socketio = require('socket.io');
const Filter = require('bad-words');
const dotenv = require('dotenv');
dotenv.config();
const db = require('./db');

const authRoutes = require('./routes/auth');
const { generateMessage, generateLocationMessage } = require('./utils/messages');
const {
  addUserSocket,
  removeUserSocket,
  getUserSocket,
  getUsersInRoom,
} = require('./utils/users');

const app = express();
const server = http.createServer(app);
const io = socketio(server, {
  cors: { origin: '*' }
});

const port = process.env.PORT || 3000;
const publicDir = path.join(__dirname, 'public');

app.use(express.json());
app.use(express.static(publicDir));
app.use('/api/auth', authRoutes);

// Simple endpoint to fetch conversation messages (paginated)
app.get('/api/messages/:room', async (req, res) => {
  const room = req.params.room;
  try {
    const result = await db.query('SELECT m.*, u.name as sender_name FROM messages m LEFT JOIN users u ON m.sender_id = u.id WHERE room=$1 ORDER BY created_at ASC LIMIT 100', [room]);
    res.json(result.rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

// Socket auth using token in query param when connecting
io.use(async (socket, next) => {
  try {
    const token = socket.handshake.query && socket.handshake.query.token;
    if (!token) return next(new Error('Authentication error'));
    const jwt = require('jsonwebtoken');
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const result = await db.query('SELECT id, name, email FROM users WHERE id=$1', [payload.id]);
    if (result.rows.length === 0) return next(new Error('Authentication error'));
    socket.user = result.rows[0];
    next();
  } catch (e) {
    console.error('Socket auth error', e.message);
    next(new Error('Authentication error'));
  }
});

io.on('connection', (socket) => {
  console.log('New WebSocket connected:', socket.id, 'user:', socket.user.email);

  socket.on('join', async (options, callback) => {
    const { error, user } = addUserSocket({ id: socket.id, username: options.username, room: options.room });
    if (error) return callback(error);
    socket.join(user.room);

    // load last messages for room and emit to this socket
    try {
      const res = await db.query('SELECT m.*, u.name as sender_name FROM messages m LEFT JOIN users u ON m.sender_id = u.id WHERE room=$1 ORDER BY created_at ASC LIMIT 100', [user.room]);
      socket.emit('roomHistory', res.rows);
    } catch (e) {
      console.error(e);
    }

    socket.emit('message', generateMessage('Admin', 'Welcome!'));
    socket.broadcast.to(user.room).emit('message', generateMessage('Admin', `${user.username} has joined!`));
    io.to(user.room).emit('roomData', { room: user.room, users: getUsersInRoom(user.room) });
    callback();
  });

  socket.on('SendMessage', async (messageText, callback) => {
    const filter = new Filter();
    if (filter.isProfane(messageText)) return callback('Profanity is not allowed');
    const user = getUserSocket(socket.id);
    if (!user) return callback('User not found');

    // Save message to DB (sender_id is socket.user.id)
    try {
      await db.query('INSERT INTO messages (sender_id, room, text) VALUES ($1,$2,$3)', [socket.user.id, user.room, messageText]);
    } catch (e) {
      console.error('DB save message error', e);
    }

    io.to(user.room).emit('message', generateMessage(user.username, messageText));
    callback();
  });

  socket.on('SendLocation', async (coords, callback) => {
    const user = getUserSocket(socket.id);
    if (!user) return callback('User not found');
    const url = `https://www.google.com/maps?q=${coords.latitude},${coords.longitude}`;
    // store as message
    try {
      await db.query('INSERT INTO messages (sender_id, room, text) VALUES ($1,$2,$3)', [socket.user.id, user.room, '[location] ' + url]);
    } catch (e) {
      console.error(e);
    }
    io.to(user.room).emit('locationmessage', generateLocationMessage(user.username, url));
    callback();
  });

  socket.on('disconnect', () => {
    const user = removeUserSocket(socket.id);
    if (user) {
      io.to(user.room).emit('message', generateMessage('Admin', `${user.username} has left`));
      io.to(user.room).emit('roomData', { room: user.room, users: getUsersInRoom(user.room) });
    }
  });
});

server.listen(port, () => console.log('Server running on port', port));
